package dbapp;

import java.time.LocalDate;
import java.time.Month;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Platy {

    static void updateSalary(EntityManager em, String name, double salary) {
        ZamestnanecPK pk1 = new ZamestnanecPK();
            pk1.setMeno(name);
            pk1.setDatum_od(LocalDate.now());           
            Zamestnanec z1 = new Zamestnanec();
            z1.setPk(pk1);
            z1.setPlat(salary);
            persist(z1);
    
    }

    static double salaryOn(EntityManager em, String name, LocalDate date) throws Exception {
        throw new Exception("neimplementovane");
    }

        
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("dbappPU");
        EntityManager em = emf.createEntityManager();
        
        ZamestnanecPK pk1 = new ZamestnanecPK();
        pk1.setMeno("JM");
        pk1.setDatum_od(LocalDate.now());           
        Zamestnanec z1 = new Zamestnanec();
        z1.setPk(pk1);

        ZamestnanecPK pk2 = new ZamestnanecPK();
        pk2.setMeno("JM");
        pk2.setDatum_od(LocalDate.now().minusDays(2));           
        Zamestnanec z2 = new Zamestnanec();
        z2.setPk(pk2);
        

        persist(z1);
        persist(z2); 
        
        
        updateSalary(em, "fero", 1000.0);
        updateSalary(em, "fero", 2000.0);

            try {
                System.out.println("" + salaryOn(em, "fero", LocalDate.now()));
                System.out.println("" + salaryOn(em, "fero", LocalDate.of(2023, Month.JULY, 28)));
                System.out.println("" + salaryOn(em, "fero", LocalDate.of(2023, Month.APRIL, 28)));
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
       
    }
    
        public static void persist(Object object) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("vsaPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(object);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbapp;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 *
 * @author edu
 */
@Entity
public class Zamestnanec implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    private ZamestnanecPK pk;
    private double plat; 

    public ZamestnanecPK getPk() {
        return pk;
    }

    public void setPk(ZamestnanecPK pk) {
        this.pk = pk;
    }

    public double getPlat() {
        return plat;
    }

    public void setPlat(double plat) {
        this.plat = plat;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.pk);
        hash = 67 * hash + (int) (Double.doubleToLongBits(this.plat) ^ (Double.doubleToLongBits(this.plat) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Zamestnanec other = (Zamestnanec) obj;
        if (Double.doubleToLongBits(this.plat) != Double.doubleToLongBits(other.plat)) {
            return false;
        }
        if (!Objects.equals(this.pk, other.pk)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Zamestnanec{" + "pk=" + pk + ", plat=" + plat + '}';
    }
        
}

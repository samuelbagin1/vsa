/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbapp;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author edu
 */
 @Embeddable
public class ZamestnanecPK implements Serializable {
   private static final long serialVersionUID = 1L;
    @Column(name = "MENO")
    private String meno;
    @Column(name = "DATUM_OD")
    private LocalDate datum_od;

    public String getMeno() {
        return meno;
    }

    public void setMeno(String meno) {
        this.meno = meno;
    }

    public LocalDate getDatum_od() {
        return datum_od;
    }

    public void setDatum_od(LocalDate datum_od) {
        this.datum_od = datum_od;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.meno);
        hash = 47 * hash + Objects.hashCode(this.datum_od);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ZamestnanecPK other = (ZamestnanecPK) obj;
        if (!Objects.equals(this.meno, other.meno)) {
            return false;
        }
        if (!Objects.equals(this.datum_od, other.datum_od)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ZamestnanecPK{" + "meno=" + meno + ", datum_od=" + datum_od + '}';
    }
    
}

package vsa;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Predmet implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(unique=true)
    private String nazov;
    @ManyToOne
    @JoinColumn(name = "PREDNASAJUCI_ID")
    private Profesor prednasajuci;
    @Column(table="PREDMET_LITERATURA", name="literatura")
    private List<String> literatura;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNazov() {
        return nazov;
    }

    public void setNazov(String nazov) {
        this.nazov = nazov;
    }

    public Profesor getPrednasajuci() {
        return prednasajuci;
    }

    public void setPrednasajuci(Profesor prednasajuci) {
        this.prednasajuci = prednasajuci;
    }

    public List<String> getLiteratura() {
        return literatura;
    }

    public void setLiteratura(List<String> literatura) {
        this.literatura = literatura;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Predmet)) {
            return false;
        }
        Predmet other = (Predmet) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "vsa.Predmet[ id=" + id + " ]";
    }
    
}

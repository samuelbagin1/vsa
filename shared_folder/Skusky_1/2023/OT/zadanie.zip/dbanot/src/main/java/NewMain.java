import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import vsa.Predmet;
import vsa.Student;

/**
 *
 * @author edu
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        vsa.Student st = new Student();
        st.setMeno("Mrkva");
        st.setRocnik("bc2");
        Predmet p = new Predmet();
        p.setNazov("VSA");
        persist(p);
        List<Predmet> pl = new ArrayList<>();
        pl.add(p);
        st.setPredmety(pl);
        persist(st);
        
    }

    public static void persist(Object object) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("vsaPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(object);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }
    
}

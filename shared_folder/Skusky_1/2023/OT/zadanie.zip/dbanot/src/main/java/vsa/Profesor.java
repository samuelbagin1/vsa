package vsa;

import java.io.Serializable;
import java.util.List;

public class Profesor extends Osoba implements Serializable {
    

    private String ustav;
    private List<Predmet> prednasky;

    public String getUstav() {
        return ustav;
    }

    public void setUstav(String ustav) {
        this.ustav = ustav;
    }

    public List<Predmet> getPrednasky() {
        return prednasky;
    }

    public void setPrednasky(List<Predmet> prednasky) {
        this.prednasky = prednasky;
    }
    
}

package vsa;

import java.io.Serializable;
import java.util.List;

public class Student extends Osoba implements Serializable {


    private String rocnik;
    private List<Predmet> predmety;

    public List<Predmet> getPredmety() {
        return predmety;
    }

    public void setPredmety(List<Predmet> predmety) {
        this.predmety = predmety;
    }

    public String getRocnik() {
        return rocnik;
    }

    public void setRocnik(String rocnik) {
        this.rocnik = rocnik;
    }

}

package dbapp;

import java.time.LocalDate;
import java.time.Month;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Platy {

    static void updateSalary(EntityManager em, String name, double salary) {
    }

    static double salaryOn(EntityManager em, String name, LocalDate date) throws Exception {
        throw new Exception("neimplementovane");
    }

        
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("dbappPU");
        EntityManager em = emf.createEntityManager();

        updateSalary(em, "fero", 1000.0);
        updateSalary(em, "fero", 2000.0);

            try {
                System.out.println("" + salaryOn(em, "fero", LocalDate.now()));
                System.out.println("" + salaryOn(em, "fero", LocalDate.of(2023, Month.JULY, 28)));
                System.out.println("" + salaryOn(em, "fero", LocalDate.of(2023, Month.APRIL, 28)));
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
       
    }

}
